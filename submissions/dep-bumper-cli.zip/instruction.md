# Interactive Dependency Bumper CLI

A Python project needs a CLI tool to manage dependency updates across both npm (Node.js) and PyPI (Python) ecosystems. The tool must read `package.json` and `requirements.txt`, detect outdated packages, allow interactive selection of updates, apply version bumps, regenerate lockfiles, and output a conventional-commit-ready summary.

## Requirements

1. **Read dependency files**: The CLI at `/app/dep_bumper.py` must:
   - Parse `/app/package.json` to extract npm dependencies (both `dependencies` and `devDependencies`)
   - Parse `/app/requirements.txt` to extract PyPI packages and their version constraints
   - Handle both files even if only one exists (graceful degradation)
   - Print `Reading dependency files` to stdout when starting this step

2. **Detect outdated packages**: For each package, determine if updates are available:
   - For npm packages: Use `npm outdated --json` to get current, wanted, and latest versions
   - For PyPI packages: Use `pip index versions <package>` or equivalent to check latest available version
   - Compare current version constraints against latest available versions
   - Identify packages that can be updated (respecting semver constraints in requirements.txt)
   - Print `Checking for outdated packages` before running version checks

3. **Interactive selection**: Present a numbered list of outdated packages and allow user selection:
   - Display format: `[index] package-name: current-version -> latest-version (ecosystem)`
   - If a requirement includes extras (e.g., `uvicorn[standard]`), include the extras in the display name
   - Use the raw `current` and `latest` version values as reported by the package managers (no added prefixes like `^` or `~` in the list)
   - Allow multiple selections (comma-separated indices or ranges like `1,3,5-7`)
   - Allow "all" to select all packages
   - Allow "skip" or empty input to proceed without updates
   - Validate input and re-prompt on invalid selections

4. **Apply version bumps**: Update the dependency files with selected versions:
   - For npm: Update `package.json` with exact versions (e.g., `"package": "^1.2.3"` -> `"package": "^2.0.0"`)
   - For PyPI: Update `requirements.txt` with exact versions or compatible constraints (e.g., `package==1.2.3` -> `package==2.0.0` or `package>=2.0.0,<3.0.0`)
   - Preserve comments and formatting in requirements.txt where possible
   - Write updated files back to disk
   - Print `Updating dependency files` before modifying any files

5. **Regenerate lockfiles**: After updating dependency files, regenerate lockfiles:
   - Run `npm install` (not `npm ci`) to update `package-lock.json` based on new `package.json`
   - Run `pip-compile requirements.txt` to regenerate `requirements.txt.lock` (if pip-tools is available)
   - Handle errors gracefully (e.g., if pip-compile is not installed, skip Python lockfile regeneration)

6. **Output conventional commit summary**: After all updates, write `/app/commit-summary.txt` containing:
   - A conventional commit message format: `chore(deps): bump <ecosystem> dependencies`
   - List of updated packages in the format: `- <package-name>: <old-version> -> <new-version>`
   - Use the same display name as the interactive list (including extras for PyPI packages)
   - Use the raw `current` and `latest` version values (no added prefixes) in summary lines
   - Separate sections labeled exactly `npm:` and `pypi:` (lowercase)
   - Example format:
     ```
     chore(deps): bump npm and PyPI dependencies

     npm:
     - express: ^4.18.0 -> ^4.19.0
     - lodash: ^4.17.21 -> ^4.17.22

     pypi:
     - requests: 2.31.0 -> 2.32.0
     - flask: 3.0.0 -> 3.0.1

7. **Finalize output**:
   - Print `Done!` after all steps complete (after writing `commit-summary.txt`)
     ```

## Constraints

- **Do not modify** files outside of `/app/` directory
- **Preserve formatting**: Maintain existing formatting and comments in `requirements.txt` where possible
- **Semver constraints**: Respect version constraints in `requirements.txt` (e.g., `>=`, `<=`, `~=`, `==`)
- **Interactive mode only**: The CLI must run interactively (read from stdin, write to stdout/stderr)
- **No external network calls for version detection**: Use `npm outdated` and `pip index versions` which work offline with cached metadata
- **Error handling**: If a package update fails (e.g., incompatible versions), log the error and continue with other packages
- **Idempotent lockfile regeneration**: Running the tool multiple times should not cause issues
- **Python 3.11+** required
- **npm and pip must be available** in the environment

## Files

- CLI script: `/app/dep_bumper.py` (broken/incomplete implementation)
- npm dependencies: `/app/package.json` (contains npm dependencies)
- npm lockfile: `/app/package-lock.json` (will be regenerated)
- Python dependencies: `/app/requirements.txt` (contains PyPI packages)
- Python lockfile: `/app/requirements.txt.lock` (will be regenerated by pip-compile)
- Output summary: `/app/commit-summary.txt` (generated by CLI)

## Outputs

- Updated `/app/package.json` (with bumped npm dependency versions)
- Updated `/app/requirements.txt` (with bumped PyPI package versions)
- Regenerated `/app/package-lock.json` (via `npm install`)
- Regenerated `/app/requirements.txt.lock` (via `pip-compile`, if pip-tools available)
- `/app/commit-summary.txt` (conventional commit message with update summary)

## Technical Notes

- `npm outdated --json` returns JSON with package names as keys and objects containing `current`, `wanted`, `latest` versions
- `pip index versions <package>` outputs available versions (may need parsing)
- For PyPI, consider using `pip list --outdated --format=json` as an alternative
- `pip-compile` requires `pip-tools` package: `pip install pip-tools`
- Conventional commit format: `<type>(<scope>): <description>` where type is `chore`, scope is `deps`
- The CLI should be executable: `python /app/dep_bumper.py` or `chmod +x /app/dep_bumper.py` with shebang

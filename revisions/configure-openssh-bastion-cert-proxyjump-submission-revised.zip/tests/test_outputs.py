"""
Tests for OpenSSH Bastion ProxyJump with Certificate Authentication.

These tests verify that the agent correctly configured:
1. ProxyJump through bastion with certificate auth
2. Proper known_hosts with @cert-authority and hashed entries
3. sshd configs with user CA trust and host certificates
4. Security constraints (no password auth, strict host key checking)

Anti-cheating measures:
- Validates that configuration files were actually modified from broken initial state
- Verifies specific required directives are present
- Ensures security settings cannot be bypassed
"""

import os
import socket
import subprocess
import time
from pathlib import Path

import pytest

BASE = Path(os.environ.get("APP_ROOT", "/app"))
BASTION_CONFIG = BASE / "bastion" / "sshd_config"
APP_CONFIG = BASE / "apphost" / "sshd_config"
SSH_CONFIG = BASE / "client" / "ssh_config"
KNOWN_HOSTS = BASE / "client" / "known_hosts"
AUTHORIZED_PRINCIPALS = BASE / "apphost" / "authorized_principals"


def _port_from_config(config_path: Path) -> int:
    """Extract the Port directive from an sshd config file."""
    for line in config_path.read_text().splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("port"):
            parts = stripped.split()
            if len(parts) >= 2:
                return int(parts[1])
    raise AssertionError(f"Port not found in {config_path}")


def _wait_for_port(port: int, timeout: float = 10.0) -> None:
    """Wait for a TCP port to become available."""
    deadline = time.time() + timeout
    last_error = None
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return
        except OSError as exc:
            last_error = exc
            time.sleep(0.1)
    raise AssertionError(f"Port {port} did not open in time: {last_error}")


def _ensure_user(username: str) -> None:
    """Ensure a system user exists for SSH testing."""
    result = subprocess.run(["id", username], capture_output=True)
    if result.returncode != 0:
        subprocess.run(["useradd", "-m", "-s", "/bin/bash", username], check=True)
    subprocess.run(["passwd", "-d", username], check=False)
    subprocess.run(["usermod", "-U", username], check=False)


def _config_with_cert(cert_path: Path) -> Path:
    """Create a temporary ssh_config with a different certificate file."""
    lines = []
    for line in SSH_CONFIG.read_text().splitlines():
        if line.strip().startswith("CertificateFile"):
            indent = line[: line.index("CertificateFile")]
            lines.append(f"{indent}CertificateFile {cert_path}")
        else:
            lines.append(line)
    temp = Path("/tmp") / f"ssh_config_{cert_path.stem}"
    temp.write_text("\n".join(lines) + "\n")
    return temp


def _start_sshd(config_path: Path, runtime_dir: Path):
    """Start an sshd instance with the given config."""
    runtime_dir.mkdir(parents=True, exist_ok=True)
    check = subprocess.run(
        ["/usr/sbin/sshd", "-t", "-f", str(config_path)],
        capture_output=True,
        text=True,
    )
    assert check.returncode == 0, f"sshd config check failed: {check.stderr}"

    logfile = runtime_dir / "sshd.log"
    proc = subprocess.Popen(
        ["/usr/sbin/sshd", "-D", "-f", str(config_path), "-E", str(logfile)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    _wait_for_port(_port_from_config(config_path))
    return proc


def _stop_proc(proc: subprocess.Popen):
    """Stop an sshd process gracefully."""
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


@pytest.fixture(scope="session")
def ssh_servers():
    """Fixture to start bastion and app sshd servers for testing."""
    _ensure_user("appuser")
    Path("/var/run/sshd").mkdir(parents=True, exist_ok=True)
    subprocess.run([f"{BASE}/bin/fix_permissions.sh"], check=True)

    bastion_proc = _start_sshd(BASTION_CONFIG, Path("/tmp/sshd-bastion"))
    app_proc = _start_sshd(APP_CONFIG, Path("/tmp/sshd-app"))

    yield

    _stop_proc(bastion_proc)
    _stop_proc(app_proc)


# =============================================================================
# Anti-Cheating Tests: Verify agent actually modified configurations
# =============================================================================

class TestConfigurationModified:
    """Tests that verify the agent actually performed work (anti-NOP measures)."""

    def test_client_ssh_config_has_proxyjump(self):
        """
        Verify client ssh_config contains ProxyJump directive.
        
        The starter file does NOT contain ProxyJump - agent must add it.
        This prevents NOP from passing.
        """
        # Check for actual directive, not just word in comments
        lines = SSH_CONFIG.read_text().splitlines()
        has_proxyjump = any(
            line.strip().lower().startswith("proxyjump") 
            for line in lines if not line.strip().startswith("#")
        )
        assert has_proxyjump, \
            "Client ssh_config must contain ProxyJump directive (starter file was missing it)"

    def test_client_ssh_config_has_certificatefile(self):
        """
        Verify client ssh_config contains CertificateFile directive.
        
        The starter file does NOT contain CertificateFile - agent must add it.
        """
        # Check for actual directive, not just word in comments
        lines = SSH_CONFIG.read_text().splitlines()
        has_certfile = any(
            line.strip().startswith("CertificateFile") 
            for line in lines if not line.strip().startswith("#")
        )
        assert has_certfile, \
            "Client ssh_config must contain CertificateFile directive (starter file was missing it)"

    def test_client_ssh_config_has_stricthostkeychecking_yes(self):
        """
        Verify client uses StrictHostKeyChecking yes (security requirement).
        
        Agent must not weaken security by using StrictHostKeyChecking no.
        """
        content = SSH_CONFIG.read_text().lower()
        # Check for "stricthostkeychecking yes" or "stricthostkeychecking=yes"
        assert "stricthostkeychecking" in content, \
            "Client ssh_config must contain StrictHostKeyChecking directive"
        # Ensure it's not set to 'no' or 'accept-new'
        lines = SSH_CONFIG.read_text().splitlines()
        for line in lines:
            if "stricthostkeychecking" in line.lower():
                lower_line = line.lower().strip()
                assert "no" not in lower_line.split("stricthostkeychecking")[1].split()[0], \
                    "StrictHostKeyChecking must be 'yes', not 'no'"

    def test_client_ssh_config_has_userknownhostsfile(self):
        """
        Verify client ssh_config specifies UserKnownHostsFile.
        
        Agent must configure client to use /app/client/known_hosts.
        """
        content = SSH_CONFIG.read_text()
        assert "UserKnownHostsFile" in content, \
            "Client ssh_config must contain UserKnownHostsFile directive"
        assert "/app/client/known_hosts" in content, \
            "UserKnownHostsFile should point to /app/client/known_hosts"

    def test_bastion_sshd_has_trustedusercakeys(self):
        """
        Verify bastion sshd_config contains TrustedUserCAKeys directive.
        
        The starter file does NOT contain TrustedUserCAKeys - agent must add it
        to enable user certificate authentication.
        """
        content = BASTION_CONFIG.read_text()
        assert "TrustedUserCAKeys" in content, \
            "Bastion sshd_config must contain TrustedUserCAKeys (starter file was missing it)"
        assert "/app/ca/user_ca.pub" in content, \
            "TrustedUserCAKeys should point to /app/ca/user_ca.pub"

    def test_bastion_sshd_has_password_auth_disabled(self):
        """
        Verify bastion sshd_config has PasswordAuthentication no.
        
        Security requirement: password authentication must be disabled.
        The starter file did NOT have this configured.
        """
        content = BASTION_CONFIG.read_text()
        assert "PasswordAuthentication" in content, \
            "Bastion sshd_config must contain PasswordAuthentication directive"
        # Verify it's set to 'no'
        lines = BASTION_CONFIG.read_text().splitlines()
        found_disabled = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("PasswordAuthentication"):
                parts = stripped.split()
                if len(parts) >= 2 and parts[1].lower() == "no":
                    found_disabled = True
        assert found_disabled, "PasswordAuthentication must be set to 'no'"

    def test_apphost_sshd_has_hostcertificate(self):
        """
        Verify app host sshd_config contains HostCertificate directive.
        
        The starter file does NOT contain HostCertificate - agent must add it
        to present the host certificate to clients.
        """
        content = APP_CONFIG.read_text()
        assert "HostCertificate" in content, \
            "App host sshd_config must contain HostCertificate (starter file was missing it)"
        assert "ssh_host_ed25519_key-cert.pub" in content, \
            "HostCertificate should point to the provided host certificate"

    def test_apphost_sshd_has_trustedusercakeys(self):
        """
        Verify app host sshd_config contains TrustedUserCAKeys directive.
        
        The starter file does NOT contain TrustedUserCAKeys - agent must add it.
        """
        content = APP_CONFIG.read_text()
        assert "TrustedUserCAKeys" in content, \
            "App host sshd_config must contain TrustedUserCAKeys (starter file was missing it)"

    def test_apphost_sshd_has_password_auth_disabled(self):
        """
        Verify app host sshd_config has PasswordAuthentication no.
        
        Security requirement: password authentication must be disabled.
        """
        content = APP_CONFIG.read_text()
        assert "PasswordAuthentication" in content, \
            "App host sshd_config must contain PasswordAuthentication directive"
        lines = APP_CONFIG.read_text().splitlines()
        found_disabled = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("PasswordAuthentication"):
                parts = stripped.split()
                if len(parts) >= 2 and parts[1].lower() == "no":
                    found_disabled = True
        assert found_disabled, "PasswordAuthentication must be set to 'no'"

    def test_apphost_has_authorized_principals_file(self):
        """
        Verify app host sshd_config has AuthorizedPrincipalsFile configured.
        
        The starter file does NOT have this - agent must add it.
        """
        content = APP_CONFIG.read_text()
        assert "AuthorizedPrincipalsFile" in content, \
            "App host sshd_config must contain AuthorizedPrincipalsFile (starter file was missing it)"

    def test_authorized_principals_contains_appuser(self):
        """
        Verify authorized_principals file contains 'appuser'.
        
        The starter file was EMPTY - agent must populate it with the principal.
        """
        content = AUTHORIZED_PRINCIPALS.read_text()
        # Skip comments
        principals = [line.strip() for line in content.splitlines() 
                     if line.strip() and not line.strip().startswith("#")]
        assert "appuser" in principals, \
            "authorized_principals must contain 'appuser' (starter file was empty)"


class TestKnownHostsConfiguration:
    """Tests for known_hosts file configuration."""

    def test_known_hosts_has_cert_authority(self):
        """
        Verify known_hosts contains @cert-authority entry.
        
        The starter file was EMPTY - agent must add @cert-authority for host CA
        to enable certificate-based host verification.
        """
        # Check for actual @cert-authority line, not just in comments
        lines = KNOWN_HOSTS.read_text().splitlines()
        has_cert_authority = any(
            line.strip().startswith("@cert-authority") 
            for line in lines if not line.strip().startswith("#")
        )
        assert has_cert_authority, \
            "known_hosts must contain @cert-authority entry (starter file was empty)"

    def test_known_hosts_has_bastion_entry(self):
        """
        Verify known_hosts contains an entry for the bastion host.
        
        Either hashed or plain entry for [127.0.0.1]:2222 is acceptable.
        """
        content = KNOWN_HOSTS.read_text()
        # Check for bastion entry (either hashed |1| prefix or plain [127.0.0.1]:2222)
        has_bastion = "|1|" in content or "[127.0.0.1]:2222" in content
        assert has_bastion, \
            "known_hosts must contain bastion host key entry"

    def test_known_hosts_is_not_empty(self):
        """
        Verify known_hosts is not empty or contains only comments.
        
        The starter file was effectively empty - agent must populate it.
        """
        content = KNOWN_HOSTS.read_text()
        # Filter out empty lines and comments
        real_entries = [line for line in content.splitlines() 
                       if line.strip() and not line.strip().startswith("#")]
        assert len(real_entries) >= 1, \
            "known_hosts must contain at least one real entry (starter was empty)"


# =============================================================================
# Functional Tests: Verify SSH connections work correctly
# =============================================================================

class TestProxyJumpFunctionality:
    """Tests for ProxyJump and certificate authentication functionality."""

    def test_proxyjump_configured(self):
        """
        Verify ssh_config properly resolves app-via-bastion with ProxyJump.
        
        Uses 'ssh -G' to dump resolved configuration and checks that:
        - proxyjump directive is present
        - bastion is specified as the jump host
        - certificate file is configured
        """
        details = subprocess.check_output(
            ["ssh", "-G", "-F", str(SSH_CONFIG), "app-via-bastion"],
            text=True,
        )
        assert "proxyjump" in details.lower(), \
            "Resolved config must show proxyjump"
        assert "bastion" in details.lower(), \
            "ProxyJump must reference bastion"
        assert f"certificatefile {BASE / 'client' / 'id_client-cert.pub'}" in details.lower(), \
            "CertificateFile must point to the client certificate"

    def test_known_hosts_hashed_and_ca_present(self):
        """
        Verify known_hosts has hashed entries and @cert-authority.
        
        Security requirements:
        - Entries should be hashed (|1| prefix) for privacy
        - @cert-authority entry for host CA enables certificate-based host verification
        """
        text = KNOWN_HOSTS.read_text()
        assert "@cert-authority" in text, "Host CA entry missing"
        lookup = subprocess.run(
            ["ssh-keygen", "-F", "[127.0.0.1]:2222", "-f", str(KNOWN_HOSTS)],
            capture_output=True,
            text=True,
        )
        assert lookup.returncode == 0, f"Bastion entry not found in known_hosts: {lookup.stderr}"
        assert "|1|" in text, "known_hosts should contain hashed entries for security"

    def test_certificate_auth_via_proxyjump(self, ssh_servers):
        """
        End-to-end test: SSH to app host via bastion using certificate auth.
        
        This is the main functional test that verifies:
        - Client can connect to bastion on port 2222
        - ProxyJump works to reach app host on port 2223
        - Certificate authentication succeeds
        - No host key prompts (known_hosts is properly configured)
        """
        result = subprocess.run(
            [
                "ssh",
                "-F",
                str(SSH_CONFIG),
                "app-via-bastion",
                "--",
                "echo",
                "ok",
            ],
            text=True,
            capture_output=True,
            env={"SSH_AUTH_SOCK": "", **os.environ},
        )
        assert result.returncode == 0, f"SSH via ProxyJump failed: {result.stderr}"
        assert result.stdout.strip() == "ok", "Expected 'ok' output from remote command"
        assert "authenticity" not in result.stderr.lower(), \
            "Host key prompt appeared - known_hosts not properly configured"

    def test_expired_cert_rejected(self, ssh_servers):
        """
        Verify that expired certificates are rejected.
        
        Security test: an expired client certificate must not be accepted.
        This ensures certificate validity checking is working.
        """
        expired_cert = BASE / "client" / "id_client-expired-cert.pub"
        cfg = _config_with_cert(expired_cert)
        result = subprocess.run(
            [
                "ssh",
                "-F",
                str(cfg),
                "app-via-bastion",
                "--",
                "echo",
                "nope",
            ],
            text=True,
            capture_output=True,
            env={"SSH_AUTH_SOCK": "", **os.environ},
        )
        assert result.returncode != 0, \
            "Expired certificate should not authenticate - certificate validation is broken"

    def test_wrong_principal_rejected(self, ssh_servers):
        """
        Verify that certificates with wrong principals are rejected.
        
        Security test: a certificate for a different principal must not grant access.
        This ensures AuthorizedPrincipalsFile is properly enforced.
        """
        wrong_cert = BASE / "client" / "id_client-wrong-principal-cert.pub"
        cfg = _config_with_cert(wrong_cert)
        result = subprocess.run(
            [
                "ssh",
                "-F",
                str(cfg),
                "app-via-bastion",
                "--",
                "echo",
                "nope",
            ],
            text=True,
            capture_output=True,
            env={"SSH_AUTH_SOCK": "", **os.environ},
        )
        assert result.returncode != 0, \
            "Wrong principal certificate should be rejected - AuthorizedPrincipalsFile not enforced"

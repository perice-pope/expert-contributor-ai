"""Tests for the Windows Artifact Timeline Correlation task."""
import csv
import json
from datetime import datetime
from pathlib import Path


def test_input_files_not_modified():
    """Anti-cheating: Verify input data files were not modified."""
    # Check that input files still exist and haven't been tampered with
    mft_path = Path("/app/data/mft_records.txt")
    evtx_path = Path("/app/data/events.evtx.txt")
    prefetch_path = Path("/app/data/prefetch.txt")
    
    assert mft_path.exists(), "MFT records file missing"
    assert evtx_path.exists(), "EVTX events file missing"
    assert prefetch_path.exists(), "Prefetch file missing"
    
    # Verify files contain expected data (not empty/corrupted)
    assert mft_path.stat().st_size > 100, "MFT records file suspiciously small"
    assert evtx_path.stat().st_size > 100, "EVTX file suspiciously small"
    assert prefetch_path.stat().st_size > 50, "Prefetch file suspiciously small"


def test_csv_timeline_exists():
    """Verify the timeline CSV file was created."""
    timeline_path = Path("/output/timeline.csv")
    assert timeline_path.exists(), "timeline.csv does not exist"


def test_csv_timeline_has_header():
    """Verify the CSV has the correct header row."""
    timeline_path = Path("/output/timeline.csv")
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        expected_header = ['timestamp', 'event_type', 'source', 'details', 'anomaly_flag', 'anomaly_reason']
        assert header == expected_header, f"Expected header {expected_header}, got {header}"


def test_csv_timeline_has_events():
    """Verify the CSV contains event rows."""
    timeline_path = Path("/output/timeline.csv")
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        rows = list(reader)
        
        assert len(rows) > 0, "CSV should contain at least one event row"


def test_timestamps_are_utc_iso_format():
    """Verify all timestamps are in UTC ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ)."""
    timeline_path = Path("/output/timeline.csv")
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 0:
                timestamp = row[0]
                # Check format: YYYY-MM-DDTHH:MM:SSZ
                assert timestamp.endswith('Z'), f"Timestamp {timestamp} should end with Z (UTC)"
                try:
                    # Try parsing the timestamp
                    dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    assert dt.tzinfo is not None, f"Timestamp {timestamp} should have timezone info"
                except ValueError:
                    assert False, f"Timestamp {timestamp} is not in valid ISO 8601 format"


def test_timeline_is_sorted_chronologically():
    """Verify events are sorted chronologically by timestamp."""
    timeline_path = Path("/output/timeline.csv")
    
    timestamps = []
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 0:
                timestamp = row[0]
                dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                timestamps.append(dt)
    
    # Check if sorted
    assert timestamps == sorted(timestamps), "Timeline events are not sorted chronologically"


def test_all_event_types_present():
    """Verify all expected event types are present in the timeline."""
    timeline_path = Path("/output/timeline.csv")
    
    event_types = set()
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 1:
                event_types.add(row[1])
    
    expected_types = {'file_creation', 'process_execution', 'service_start', 'registry_modification'}
    assert expected_types.issubset(event_types), f"Missing event types. Expected {expected_types}, got {event_types}"


def test_all_sources_present():
    """Verify all expected sources (MFT, EVTX, Prefetch) are present."""
    timeline_path = Path("/output/timeline.csv")
    
    sources = set()
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 2:
                sources.add(row[2])
    
    expected_sources = {'MFT', 'EVTX', 'Prefetch'}
    assert expected_sources.issubset(sources), f"Missing sources. Expected {expected_sources}, got {sources}"


def test_json_summary_exists():
    """Verify the suspicious events JSON file was created."""
    json_path = Path("/output/suspicious_events.json")
    assert json_path.exists(), "suspicious_events.json does not exist"


def test_json_summary_is_valid():
    """Verify the JSON file is valid JSON."""
    json_path = Path("/output/suspicious_events.json")
    
    with open(json_path, 'r') as f:
        try:
            data = json.load(f)
            assert isinstance(data, list), "JSON should contain an array"
        except json.JSONDecodeError as e:
            assert False, f"Invalid JSON: {e}"


def test_json_summary_has_required_fields():
    """Verify each suspicious event has required fields."""
    json_path = Path("/output/suspicious_events.json")
    
    with open(json_path, 'r') as f:
        data = json.load(f)
        
        required_fields = {'timestamp', 'event_type', 'source', 'details', 'anomaly_type', 'reason'}
        
        for event in data:
            assert isinstance(event, dict), "Each event should be a dictionary"
            for field in required_fields:
                assert field in event, f"Event missing required field: {field}"


def test_unsigned_binary_detected():
    """Verify unsigned binary executions from input data are correctly flagged in JSON summary."""
    json_path = Path("/output/suspicious_events.json")
    
    # Anti-cheating: Check that specific unsigned binaries from input are flagged
    # From events.evtx.txt: suspicious.exe and service.dll have Signed:false
    expected_unsigned = ['suspicious.exe', 'service.dll']
    
    with open(json_path, 'r') as f:
        data = json.load(f)
        
        # Look for unsigned binary execution events
        unsigned_found = False
        unsigned_binaries_detected = []
        
        for event in data:
            if event.get('anomaly_type') == 'Unsigned binary execution':
                unsigned_found = True
                assert event.get('event_type') == 'process_execution', "Unsigned binary should be process_execution"
                
                # Extract binary name from details
                details = event.get('details', '')
                for expected in expected_unsigned:
                    if expected in details:
                        unsigned_binaries_detected.append(expected)
        
        assert unsigned_found, "At least one unsigned binary execution should be flagged"
        
        # Anti-cheating: Verify at least one known unsigned binary from input data is detected
        assert len(unsigned_binaries_detected) > 0, \
            f"Should detect unsigned binaries from input data (e.g., {expected_unsigned})"


def test_registry_run_key_detected():
    """Verify registry Run key modifications from input data are flagged."""
    json_path = Path("/output/suspicious_events.json")
    
    # Anti-cheating: From events.evtx.txt there are 2 EventID:4657 with Run keys
    # Both should be detected as anomalies
    
    with open(json_path, 'r') as f:
        data = json.load(f)
        
        # Look for registry Run key modifications
        run_key_found = False
        run_key_count = 0
        
        for event in data:
            if event.get('anomaly_type') == 'Registry Run key modification':
                run_key_found = True
                run_key_count += 1
                assert event.get('event_type') == 'registry_modification', "Run key should be registry_modification"
                # Check that details contain 'run' (case-insensitive)
                details_lower = event.get('details', '').lower()
                assert 'run' in details_lower, "Details should mention 'run'"
        
        assert run_key_found, "At least one registry Run key modification should be flagged"
        
        # Anti-cheating: Verify detection from actual input data
        # Input has 2 Run key modifications (malware.exe and startup.exe)
        assert run_key_count >= 1, f"Should detect Run key modifications from input data (found {run_key_count})"


def test_specific_input_events_in_timeline():
    """Anti-cheating: Verify specific events from input files appear in timeline."""
    timeline_path = Path("/output/timeline.csv")
    
    # Read timeline
    timeline_events = []
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if len(row) >= 4:
                timeline_events.append({
                    'timestamp': row[0],
                    'event_type': row[1],
                    'source': row[2],
                    'details': row[3]
                })
    
    # Verify specific events from input data appear in timeline
    # From mft_records.txt: notepad.exe with specific timestamp
    mft_found = any('notepad.exe' in e['details'] and e['source'] == 'MFT' 
                    for e in timeline_events)
    assert mft_found, "Should find notepad.exe from MFT records in timeline"
    
    # From events.evtx.txt: EventID:4688 for cmd.exe
    evtx_found = any('cmd.exe' in e['details'] and e['source'] == 'EVTX' 
                     for e in timeline_events)
    assert evtx_found, "Should find cmd.exe from EVTX events in timeline"
    
    # From prefetch.txt: powershell.exe with epoch timestamp
    prefetch_found = any('powershell.exe' in e['details'] and e['source'] == 'Prefetch' 
                         for e in timeline_events)
    assert prefetch_found, "Should find powershell.exe from Prefetch in timeline"


def test_csv_anomaly_flags_match_json():
    """Verify anomaly flags in CSV match the events in JSON summary."""
    timeline_path = Path("/output/timeline.csv")
    json_path = Path("/output/suspicious_events.json")
    
    # Collect timestamps of anomalous events from CSV
    csv_anomalous_timestamps = set()
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 4:
                anomaly_flag = row[4].lower()
                if anomaly_flag == 'true':
                    csv_anomalous_timestamps.add(row[0])  # timestamp
    
    # Collect timestamps from JSON
    with open(json_path, 'r') as f:
        json_data = json.load(f)
        json_timestamps = {event['timestamp'] for event in json_data}
    
    # All JSON timestamps should be in CSV anomalous set
    assert json_timestamps.issubset(csv_anomalous_timestamps), \
        "All events in JSON summary should have anomaly_flag=True in CSV"


def test_mft_events_in_timeline():
    """Verify MFT file creation events are present in the timeline."""
    timeline_path = Path("/output/timeline.csv")
    
    mft_events_found = False
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 2 and row[2] == 'MFT' and row[1] == 'file_creation':
                mft_events_found = True
                break
    
    assert mft_events_found, "MFT file creation events should be present in timeline"


def test_evtx_events_in_timeline():
    """Verify EVTX events (process execution, service start, registry) are present."""
    timeline_path = Path("/output/timeline.csv")
    
    evtx_process = False
    evtx_service = False
    evtx_registry = False
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 2 and row[2] == 'EVTX':
                if row[1] == 'process_execution':
                    evtx_process = True
                elif row[1] == 'service_start':
                    evtx_service = True
                elif row[1] == 'registry_modification':
                    evtx_registry = True
    
    assert evtx_process, "EVTX process execution events should be present"
    assert evtx_service, "EVTX service start events should be present"
    assert evtx_registry, "EVTX registry modification events should be present"


def test_prefetch_events_in_timeline():
    """Verify Prefetch process execution events are present."""
    timeline_path = Path("/output/timeline.csv")
    
    prefetch_found = False
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 2 and row[2] == 'Prefetch' and row[1] == 'process_execution':
                prefetch_found = True
                break
    
    assert prefetch_found, "Prefetch process execution events should be present in timeline"


def test_source_values_exact_case():
    """Verify source values use exact title case: MFT, EVTX, Prefetch (not lowercase)."""
    timeline_path = Path("/output/timeline.csv")
    
    valid_sources = {'MFT', 'EVTX', 'Prefetch'}
    invalid_sources = {'mft', 'evtx', 'prefetch', 'Mft', 'Evtx', 'PREFETCH'}
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 2:
                source = row[2]
                assert source in valid_sources, \
                    f"Source value '{source}' must be exactly one of: MFT, EVTX, Prefetch (title case)"
                assert source not in invalid_sources, \
                    f"Source value '{source}' must not be lowercase or other case variants"


def test_anomaly_flag_exact_lowercase():
    """Verify anomaly_flag values are exactly lowercase 'true' or 'false' (not Python booleans)."""
    timeline_path = Path("/output/timeline.csv")
    
    valid_flags = {'true', 'false'}
    invalid_flags = {'True', 'False', 'TRUE', 'FALSE', '1', '0', 'yes', 'no'}
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        
        for row in reader:
            if len(row) > 4:
                anomaly_flag = row[4]
                assert anomaly_flag in valid_flags, \
                    f"anomaly_flag '{anomaly_flag}' must be exactly lowercase 'true' or 'false'"
                assert anomaly_flag not in invalid_flags, \
                    f"anomaly_flag '{anomaly_flag}' must not be capitalized or other variants"


def test_edt_est_timezone_conversion():
    """Verify both EST and EDT timestamps are correctly converted to UTC (EST=UTC-5, EDT=UTC-4)."""
    timeline_path = Path("/output/timeline.csv")
    
    # Read MFT input to check for EST/EDT timestamps
    mft_path = Path("/app/data/mft_records.txt")
    has_est = False
    has_edt = False
    
    with open(mft_path, 'r') as f:
        for line in f:
            if ' EST' in line:
                has_est = True
            if ' EDT' in line:
                has_edt = True
    
    # If input has EST/EDT, verify conversion
    if has_est or has_edt:
        with open(timeline_path, 'r') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            
            for row in reader:
                if len(row) > 0:
                    timestamp = row[0]
                    # All timestamps should end with Z (UTC)
                    assert timestamp.endswith('Z'), \
                        f"All timestamps must be UTC (end with Z), got: {timestamp}"
                    
                    # Parse and verify it's valid UTC
                    try:
                        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        assert dt.tzinfo is not None, \
                            f"Timestamp {timestamp} must have timezone info"
                        # Verify it's UTC (offset 0)
                        assert dt.utcoffset().total_seconds() == 0, \
                            f"Timestamp {timestamp} must be UTC (offset 0)"
                    except ValueError:
                        assert False, f"Invalid timestamp format: {timestamp}"


def test_json_only_flagged_events():
    """Verify JSON summary contains ONLY flagged/suspicious events (not all events)."""
    timeline_path = Path("/output/timeline.csv")
    json_path = Path("/output/suspicious_events.json")
    
    # Count total events in CSV
    total_csv_events = 0
    flagged_csv_events = 0
    
    with open(timeline_path, 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        for row in reader:
            if len(row) > 4:
                total_csv_events += 1
                if row[4].lower() == 'true':
                    flagged_csv_events += 1
    
    # Count events in JSON
    with open(json_path, 'r') as f:
        json_data = json.load(f)
        json_event_count = len(json_data)
    
    # JSON should only contain flagged events
    assert json_event_count == flagged_csv_events, \
        f"JSON should contain only flagged events ({flagged_csv_events}), but has {json_event_count}"
    
    # JSON should have fewer events than total CSV (unless all events are flagged)
    assert json_event_count <= total_csv_events, \
        f"JSON cannot have more events than CSV total ({total_csv_events})"
    
    # Verify all JSON events have anomaly_type
    for event in json_data:
        assert 'anomaly_type' in event, "All JSON events must have anomaly_type field"
        assert event['anomaly_type'] in ['Unsigned binary execution', 'Registry Run key modification'], \
            f"anomaly_type must be exactly one of the two allowed values, got: {event.get('anomaly_type')}"


def test_anomaly_type_exact_strings():
    """Verify anomaly_type values are exactly 'Unsigned binary execution' or 'Registry Run key modification'."""
    json_path = Path("/output/suspicious_events.json")
    
    valid_anomaly_types = {'Unsigned binary execution', 'Registry Run key modification'}
    invalid_variants = {
        'unsigned binary execution', 'Unsigned Binary Execution', 'UNSIGNED BINARY EXECUTION',
        'registry run key modification', 'Registry Run Key Modification', 'REGISTRY RUN KEY MODIFICATION',
        'unsigned_binary_execution', 'registry_run_key_modification'
    }
    
    with open(json_path, 'r') as f:
        json_data = json.load(f)
        
        for event in json_data:
            anomaly_type = event.get('anomaly_type', '')
            assert anomaly_type in valid_anomaly_types, \
                f"anomaly_type '{anomaly_type}' must be exactly one of: {valid_anomaly_types}"
            assert anomaly_type not in invalid_variants, \
                f"anomaly_type '{anomaly_type}' must match exact case and format"
